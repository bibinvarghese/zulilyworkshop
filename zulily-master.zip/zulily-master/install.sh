#!/bin/bash
#[notebook] 1  
pip install --upgrade pip

pip install tensorflow==2.7.1


# [notebook] 2 
pip install sklearn

# [notebook] 3,4,5 

pip install --upgrade "tfx[kfp]<2" --user
pip install -U tfx
pip install google-cloud-aiplatform

# [notebook] 6 

pip install tensorflow-datasets
pip install -U tensorboard-plugin-profile

# [notebook] 7B
pip install opencv-python

# [notebook] 8
pip install --upgrade google-cloud-vision
pip install glcoud

