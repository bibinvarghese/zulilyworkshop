# Zulily Workshop

## Notebooks:
1) 1_tf_fashion_MNIST.ipynb - Tensorflow model training using Fashion MNIST dataset.
2) 2_tf_feature_columns.ipynb - classify structured data with Tensorflow Feature Column
3) 3_tfx_end__to_end_pipeline.ipynb - TFX end to end pipeline integration on vertex AI.
4) 6_tf_profiler_implementation.ipynb - Tensorflow profiler.

## installation:
1) install.sh - To install the required packages for the notebooks.
2) After running install.sh file we need to restart the kernel.
3) Run the notebooks.
